package com.example.Aula06Tarefa;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Pet thor, rex, luna, mia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        thor = new Pet("Thor", "Preto e branco", "Sem raça definida", 2, "29 de julho", R.drawable.thor);
        rex = new Pet("Rex", "Marrom", "Pastor Alemão", 4, "15 de maio", R.drawable.rex);
        luna = new Pet("Luna", "Cinza", "Persa", 3, "10 de janeiro", R.drawable.luna);
        mia = new Pet("Mia", "Branca", "Siamês", 1, "20 de março", R.drawable.mia);

        Button btnThor = findViewById(R.id.btnThor);
        Button btnRex = findViewById(R.id.btnRex);
        Button btnLuna = findViewById(R.id.btnLuna);
        Button btnMia = findViewById(R.id.btnMia);

        btnThor.setOnClickListener(v -> abrirDetalhes(thor));
        btnRex.setOnClickListener(v -> abrirDetalhes(rex));
        btnLuna.setOnClickListener(v -> abrirDetalhes(luna));
        btnMia.setOnClickListener(v -> abrirDetalhes(mia));
    }

    private void abrirDetalhes(Pet pet) {
        Intent intent = new Intent(MainActivity.this, DetalhesPetActivity.class);
        intent.putExtra("nome", pet.getNome());
        intent.putExtra("cor", pet.getCor());
        intent.putExtra("raca", pet.getRaca());
        intent.putExtra("idade", pet.getIdade());
        intent.putExtra("aniversario", pet.getAniversario());
        intent.putExtra("imagemId", pet.getImagemId());
        startActivity(intent);
    }
}
