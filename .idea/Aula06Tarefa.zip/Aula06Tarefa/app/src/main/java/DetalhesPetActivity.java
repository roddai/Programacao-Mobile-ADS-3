package com.example.Aula06Tarefa;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetalhesPetActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes);

        ImageView imgPet = findViewById(R.id.imgPet);
        TextView txtNome = findViewById(R.id.txtNome);
        TextView txtCor = findViewById(R.id.txtCor);
        TextView txtRaca = findViewById(R.id.txtRaca);
        TextView txtIdade = findViewById(R.id.txtIdade);
        TextView txtAniversario = findViewById(R.id.txtAniversario);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            txtNome.setText("Nome: " + extras.getString("nome"));
            txtCor.setText("Cor: " + extras.getString("cor"));
            txtRaca.setText("Raça: " + extras.getString("raca"));
            txtIdade.setText("Idade: " + extras.getInt("idade"));
            txtAniversario.setText("Aniversário: " + extras.getString("aniversario"));
            imgPet.setImageResource(extras.getInt("imagemId"));
        }
    }
}
